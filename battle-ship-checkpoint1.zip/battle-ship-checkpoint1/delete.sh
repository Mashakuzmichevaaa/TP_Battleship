#! /bin/sh

rm -rf build
rm run
