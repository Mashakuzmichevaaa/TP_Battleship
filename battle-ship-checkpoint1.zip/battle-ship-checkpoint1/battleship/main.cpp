#include "game.h"

int main() {
  Game();
}

