#ifndef BATTLESHIP__GAME_H_
#define BATTLESHIP__GAME_H_

#include "player.h"

#include <iostream>
#include <sstream>

template<size_t len>
void Position(Point &begin, Point &end, ProtectionField &field) {
  std::string point;
  bool ship_was_added = false;
  while (!ship_was_added) {
    if (&begin == &end) {
      std::cin >> point;
      begin.SetX(point[0] - 'A');
      if (point.length() == 2) {
        begin.SetY(point[1] - '1');
      } else {
        begin.SetY((point[1] - '0') * 10 + (point[2] - '0') - 1);
      }
    } else {
      std::cin >> point;
      begin.SetX(point[0] - 'A');
      if (point[2] == ':') {
        begin.SetY(point[1] - '1');
        end.SetX(point[3] - 'A');
        if(point.length() == 5) {
          end.SetY(point[4] - '1');
        } else {
          end.SetY((point[4] - '0') * 10 + (point[5] - '0') - 1);
        }
      } else {
        begin.SetY((point[1] - '0') * 10 + (point[2] - '0') - 1);
        end.SetX(point[4] - 'A');
        if(point.length() == 6) {
          end.SetY(point[5] - '1');
        } else {
          end.SetY((point[5] - '0') * 10 + (point[6] - '0') - 1);
        }
      }
    }
    if ((begin.GetX() < 10 && begin.GetX() > -1 &&
        begin.GetY() < 10 && begin.GetY() > -1) &&
        (end.GetX() < 10 && end.GetX() > -1 &&
            end.GetY() < 10 && end.GetY() > -1)) {
      if ((begin.GetX() == end.GetX() && std::abs(begin.GetY() - end.GetY()) == (len - 1))
          || std::abs((begin.GetX() - end.GetX())) == (len - 1) && begin.GetY() == end.GetY()) {
        Ship<len> A(begin, end);
        ship_was_added = field.AddShip(A);
      }
    }
    if (!ship_was_added) {
      std::cout << "you cannot choose this position for your ship!" << '\n';
    }
  }
  std::cout << field;
}

void Game() {
  std::cout << "3 <=> misshot" << '\n' << "7 <=> enemy's ship was shot" << '\n' << "0 <=> free part of field" << '\n'
            << "1 <=> your ship" << '\n' << "2 <=> part of the ship was shot" << '\n' << '\n' << '\n';

  std::cout << "PLAYER_1 add four one-deck ships" << '\n';
  std::cout << "to add one-deck ship write only point (for example 'A1')" << '\n';
  Point OO, OS, OT, OF, DO_B, DO_E, DS_B, DS_E, DT_B, DT_E, TO_B, TO_E, TS_B, TS_E, FO_B, FO_E;
  ProtectionField field;
  std::cout << field;
  Position<1>(OO, OO, field);
  Position<1>(OS, OS, field);
  Position<1>(OT, OT, field);
  Position<1>(OF, OF, field);
  std::cout << "PLAYER_1 add three double-deck ships" << '\n';
  std::cout << "to add two-deck ship write two points (begin and end of the ship) and colon(for example 'A1:A2')" << '\n';
  Position<2>(DO_B, DO_E, field);
  Position<2>(DS_B, DS_E, field);
  Position<2>(DT_B, DT_E, field);
  std::cout << "PLAYER_1 add two three-deck ships" << '\n';
  std::cout << "to add tree-deck ship write two points (begin and end of the ship) and colon(for example 'A1:A3')" << '\n';
  Position<3>(TO_B, TO_E, field);
  Position<3>(TS_B, TS_E, field);
  std::cout << "PLAYER_1 add four-deck ship" << '\n';
  std::cout << "to add four-deck ship write two points (begin and end of the ship) and colon(for example 'A1:A4')" << '\n';
  Position<4>(FO_B, FO_E, field);
  Player player_1(OO, OS, OT, OF, DO_B, DO_E, DS_B, DS_E, DT_B, DT_E, TO_B, TO_E, TS_B, TS_E, FO_B, FO_E);
  system("clear");

  Point OO_, OS_, OT_, OF_, DO_B_, DO_E_, DS_B_, DS_E_, DT_B_, DT_E_, TO_B_, TO_E_, TS_B_, TS_E_, FO_B_, FO_E_;
  ProtectionField field_;
  std::cout << field_;
  std::cout << "PLAYER_2 add four one-deck ships" << '\n';
  std::cout << "to add one-deck ship write only point (for example 'A1')" << '\n';
  Position<1>(OO_, OO_, field_);
  Position<1>(OS_, OS_, field_);
  Position<1>(OT_, OT_, field_);
  Position<1>(OF_, OF_, field_);
  std::cout << "PLAYER_2 add three double-deck ships" << '\n';
  std::cout << "to add two-deck ship write two points (begin and end of the ship) and colon(for example 'A1:A2')" << '\n';
  Position<2>(DO_B_, DO_E_, field_);
  Position<2>(DS_B_, DS_E_, field_);
  Position<2>(DT_B_, DT_E_, field_);
  std::cout << "PLAYER_2" << "\n" << "add two three-deck ships" << '\n';
  std::cout << "to add tree-deck ship write two points (begin and end of the ship) and colon(for example 'A1:A3')" << '\n';
  Position<3>(TO_B_, TO_E_, field_);
  Position<3>(TS_B_, TS_E_, field_);
  std::cout << "PLAYER_2" << "\n" << "add four-deck ship" << '\n';
  std::cout << "to add four-deck ship write two points (begin and end of the ship) and colon(for example 'A1:A4')" << '\n';
  Position<4>(FO_B_, FO_E_, field_);
  Player
      player_2(OO_, OS_, OT_, OF_, DO_B_, DO_E_, DS_B_, DS_E_, DT_B_, DT_E_, TO_B_, TO_E_, TS_B_, TS_E_, FO_B_, FO_E_);
  std::cout << '\n' << '\n' << '\n' << '\n' << '\n' << '\n' << '\n' << '\n' << '\n' << '\n';
  bool ID = true;
  std::string point;
  Point pnt;
  while (player_1.life && player_2.life) {
    std::cout << '\n' << '\n' << '\n' << '\n' << '\n';
    if (ID) {
      std::cout << "PLAYER_1 attack" << '\n';
      std::cout << player_1.attack_;
      std::cout << player_1.protection_;
      std::cin >> point;
      pnt.SetX(point[0] - 'A');
      if (point.length() == 2) {
        pnt.SetY(point[1] - '1');
      } else {
        pnt.SetY((point[1] - '0') * 10 + (point[2] - '0') - 1);
      }
      ID = player_1.Attack(player_2, pnt);
      std::cout << player_1.attack_;
    } else {
      std::cout << "PLAYER_2 attack" << '\n';
      std::cout << player_2.attack_;
      std::cout << player_2.protection_;
      std::cin >> point;
      pnt.SetX(point[0] - 'A');
      if (point.length() == 2) {
        pnt.SetY(point[1] - '1');
      } else {
        pnt.SetY((point[1] - '0') * 10 + (point[2] - '0') - 1);
      }
      ID = not(player_2.Attack(player_1, pnt));
      std::cout << player_2.attack_;
    }
    system("clear");
  }
}

#endif
