#ifndef BATTLESHIP__FIELD_H_
#define BATTLESHIP__FIELD_H_

#include "point.h"

#include <vector>

class Field {
 private:
  const size_t size = 10;
  const int free_point = 0;
  std::vector<std::vector<int>> field_;
 public:
  explicit Field(std::vector<std::vector<int>> &field) : field_(field) {
    for (int i = 0; i < size; ++i) {
      for (int j = 0; j < size; ++j) {
        field_[j][i] = free_point;
      }
    }
  }
  Field() : field_(size, std::vector<int>()) {
    for (int i = 0; i < size; ++i) {
      field_[i].resize(size);
      for (int j = 0; j < size; ++j) {
        field_[i][j] = free_point;
      }
    }
  }
  int GetPoint(size_t x, size_t y) {
    return field_[x][y];
  }
  int GetPoint(Point &pnt) {
    return field_[pnt.GetX()][pnt.GetY()];
  }
  void SetPoint(Point &pnt, int t) {
    field_[pnt.GetX()][pnt.GetY()] = t;
  }
  void SetPoint(int a, int o, int t) {
    field_[a][o] = t;
  }
  friend std::ostream &operator<<(std::ostream &out, Field field);
};
std::ostream &operator<<(std::ostream &out, Field field) {
  out << "   A B C D E F G H I J" << '\n';
  for (int i = 0; i < field.size; ++i) {
    (i < 9) ? (out << i + 1 << "  ") : (out << i + 1 << " ");
    for (int j = 0; j < field.size; ++j) {
      out << field.field_[j][i] << " ";
    }
    out << '\n';
  }
  return out;
}
#endif

