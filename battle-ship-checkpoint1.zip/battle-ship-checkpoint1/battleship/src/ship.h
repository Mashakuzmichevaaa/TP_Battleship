#ifndef BATTLESHIP__SHIP_H_
#define BATTLESHIP__SHIP_H_

#include "point.h"

#include<iostream>

template<size_t N>
class Ship {
 private:
  Point start_;
  Point last_;
  int* ship_ = new int[N];
 public:
  bool condition = true;
  explicit Ship(): start_(0, 0), last_(0, 0 + N - 1) {
    for (int i = 0; i < N; ++i) {
      ship_[i] = 1;
    }
  }
  explicit Ship (Point &start, Point &last ) : start_(start), last_(last) {
    if ((start_.GetY() == last_.GetY() && start_.GetX() > last_.GetX()) ||
        (start_.GetY() > last_.GetY() && start_.GetX() == last_.GetX()) ) {
      std::swap(start_,last_);
    }
    for (int i = 0; i < N; ++i) {
      ship_[i] = 1;
    }
  }
  void Wound(Point &other) {
    if (start_.GetX() == last_.GetX()) {
      if (start_.GetX() != other.GetX()) {
        return;
      }
      if ((other.GetY() - start_.GetY()) * (other.GetY() - last_.GetY()) > 0) {
        return;
      }
      size_t num = std::abs(other.GetY() - start_.GetY());
      ship_[num] = -1;
    } else if (start_.GetY() == last_.GetY()){
      if (start_.GetY() != other.GetY()) {
        return;
      }
      if ((other.GetX() - start_.GetX()) * (other.GetX() - last_.GetX()) > 0) {
        return;
      }
      size_t num = std::abs(other.GetX() - start_.GetX());
      ship_[num] = -1;
    }
    bool alive = false;
    for (int i = 0; i < N; ++i) {
      if (ship_[i] > 0) {
        alive = true;
        break;
      }
    }
    condition = alive;
    CheckOut();
  }
  void CheckOut() {
    if (not condition) {
      std::cout << "ship len " << N << " was defeated" << '\n';
    }
  }
  void SetStart (Point &pnt) {
    start_ = pnt;
  }
  void SetLast (Point &pnt) {
    last_ = pnt;
  }
  Point GetStart() const {
    return start_;
  };
  Point GetLast() const {
    return last_;
  }
  ~Ship() {
    delete[] ship_;
  }
};

#endif
