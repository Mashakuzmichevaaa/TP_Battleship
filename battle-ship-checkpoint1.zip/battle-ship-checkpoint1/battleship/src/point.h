#ifndef BATTLESHIP__POINT_H_
#define BATTLESHIP__POINT_H_

#include <iostream>

class Point {
 private:
  int x_;
  int y_;
 public:
  explicit Point(int a = 0, int o= 0): x_(a), y_(o) {}
  int GetX() const {
    return x_;
  }
  int GetY() const {
    return y_;
  }
  Point (const Point &other): x_(other.GetX()), y_(other.GetY()) {}

  Point& operator=(const Point &other) {
    if (x_ == other.GetX() && y_ == other.GetY()) {
      return *this;
    }
    x_ = other.GetX();
    y_ = other.GetY();
    return *this;
  }
  void SetX(size_t x) {
    x_ = int(x);
  }
  void SetY(size_t y) {
    y_ = int(y);
  }
  bool operator==(Point &other) const{
    return (other.y_ == y_ && other.x_ == x_);
  }
};

#endif
