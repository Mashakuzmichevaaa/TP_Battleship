#ifndef BATTLESHIP__PROTECTION_FIELD_H_
#define BATTLESHIP__PROTECTION_FIELD_H_

#include "field.h"
#include "ship.h"
#include "point.h"

class ProtectionField : public Field {
 public:
  explicit ProtectionField(std::vector<std::vector<int>> field) : Field(field) {}
  ProtectionField() : Field() {}

  template<size_t N>
  bool AddShip(Ship<N> &ship) {
    if (ship.GetStart().GetY() == ship.GetLast().GetY()) {
      for (int i = 0; i < N; ++i) {
        if (Field::GetPoint(ship.GetStart().GetX() + i, ship.GetStart().GetY()) == 1) {
          return false;
        }
      }
      if (ship.GetStart().GetY() > 0) {
        for (int i = 0; i < N; ++i) {
          if (Field::GetPoint(ship.GetStart().GetX() + i, ship.GetStart().GetY() - 1) == 1) {
            return false;
          }
        }
      }
      if (ship.GetStart().GetY() < 9) {
        for (int i = 0; i < N; ++i) {
          if (Field::GetPoint(ship.GetStart().GetX() + i, ship.GetStart().GetY() + 1) == 1) {
            return false;
          }
        }
      }
      if (ship.GetStart().GetX() > 0 && ship.GetLast().GetX() > 0) {
        if (Field::GetPoint(ship.GetStart().GetX() - 1, ship.GetStart().GetY()) == 1) {
          return false;
        }
      }
      if (ship.GetStart().GetX() < 9 && ship.GetLast().GetX() < 9) {
        if (Field::GetPoint(ship.GetLast().GetX() + 1, ship.GetLast().GetY()) == 1) {
          return false;
        }
      }
      for (int i = 0; i < N; ++i) {
        Field::SetPoint(ship.GetStart().GetX() + i, ship.GetStart().GetY(), 1);
      }
    } else {
      for (int i = 0; i < N; ++i) {
        if (Field::GetPoint(ship.GetStart().GetX(), ship.GetStart().GetY() + i) == 1) {
          return false;
        }
      }
      if (ship.GetStart().GetX() > 0) {
        for (int i = 0; i < N; ++i) {
          if (Field::GetPoint(ship.GetStart().GetX() - 1, ship.GetStart().GetY() + i) == 1) {
            return false;
          }
        }
      }
      if (ship.GetStart().GetX() < 9) {
        for (int i = 0; i < N; ++i) {
          if (Field::GetPoint(ship.GetStart().GetX() + 1, ship.GetStart().GetY() + i) == 1) {
            return false;
          }
        }
      }
      if (ship.GetStart().GetY() > 0 && ship.GetLast().GetY() > 0) {
        if (Field::GetPoint(ship.GetStart().GetX(), ship.GetStart().GetY() - 1) == 1) {
          return false;
        }
      }
      if (ship.GetStart().GetY() < 9 && ship.GetLast().GetY() < 9) {
        if (Field::GetPoint(ship.GetLast().GetX(), ship.GetLast().GetY() + 1) == 1) {
          return false;
        }
      }
      for (int i = 0; i < N; ++i) {
        Field::SetPoint(ship.GetStart().GetX(), ship.GetStart().GetY() + i, 1);
      }
    }
    return true;
  }
  ~ProtectionField() = default;
};
#endif
