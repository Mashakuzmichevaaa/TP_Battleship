#ifndef BATTLESHIP__ATTACK_FIELD_H_
#define BATTLESHIP__ATTACK_FIELD_H_

#include "field.h"
#include "point.h"

#include <vector>

class AttackField: public Field {
 public:
  explicit AttackField(std::vector<std::vector<int>> field) : Field(field) {}
  AttackField(): Field() {}
  ~AttackField() = default;
};
#endif
